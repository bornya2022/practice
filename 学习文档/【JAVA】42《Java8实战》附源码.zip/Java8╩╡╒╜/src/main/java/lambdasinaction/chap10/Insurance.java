package lambdasinaction.chap10;

public class Insurance {

    private String name;

    public String getName() {
        return name;
    }
}

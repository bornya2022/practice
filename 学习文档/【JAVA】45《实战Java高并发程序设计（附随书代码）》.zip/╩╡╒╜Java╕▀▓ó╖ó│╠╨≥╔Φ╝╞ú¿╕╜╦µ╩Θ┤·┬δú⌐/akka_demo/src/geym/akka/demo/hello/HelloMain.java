package geym.akka.demo.hello;


public class HelloMain {

  public static void main(String[] args) {
	  
    akka.Main.main(new String[] { HelloWorld.class.getName() });
  }
}

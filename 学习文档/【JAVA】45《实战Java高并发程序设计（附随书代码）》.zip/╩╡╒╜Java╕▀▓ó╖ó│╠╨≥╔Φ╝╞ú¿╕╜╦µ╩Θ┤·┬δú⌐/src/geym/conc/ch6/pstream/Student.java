package geym.conc.ch6.pstream;

public class Student {
	public int score;
	public String id;
	public Student(String id,int score){
		this.id=id;
		this.score=score;
	}
}

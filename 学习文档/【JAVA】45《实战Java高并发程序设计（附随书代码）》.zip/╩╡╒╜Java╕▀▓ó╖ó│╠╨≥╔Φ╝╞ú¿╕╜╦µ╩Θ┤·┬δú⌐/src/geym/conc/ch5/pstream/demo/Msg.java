package geym.conc.ch5.pstream.demo;

public class Msg {
	public double i;
	public double j;
	public String orgStr=null;
}

package geym.conc.ch5.singleton;

public class SingletonDemo {

	public static void main(String[] args) {
		System.out.println(StaticSingleton.getInstance());
	}

}
 
package geym.conc.ch5.simplefuture;

public interface Data {
    public String getResult();
}

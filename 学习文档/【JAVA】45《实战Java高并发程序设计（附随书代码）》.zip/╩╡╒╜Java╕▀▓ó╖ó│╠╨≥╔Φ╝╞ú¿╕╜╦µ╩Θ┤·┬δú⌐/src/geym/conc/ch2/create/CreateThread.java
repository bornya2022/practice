package geym.conc.ch2.create;

public class CreateThread {
	public static void main(String[] args) {
		Thread t1=new Thread();
		t1.start();
	}
}
